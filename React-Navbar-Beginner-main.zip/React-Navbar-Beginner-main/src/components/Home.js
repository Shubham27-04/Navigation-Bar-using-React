import "./HomeStyles.css";

function Home() {
  return (
    <>
      <div className="home">
        <h1>React Navbar</h1>
        <h3>Difficulty Level: 0;</h3>
      </div>
    </>
  );
}

export default Home;
